searchrange = 4;
blocksize = 8;

s = imread('./provided/Frame1.png');
g = imread('./provided/Frame2.png');
m=1;
n=1;
motion = zeros(size(s,1)/blocksize,size(s,2)/blocksize,2);
for block_y = 1:size(s,1)/blocksize
    for block_x = 1:size(s,2)/blocksize
        m = 1+(block_y-1)*blocksize;
        n = 1+(block_x-1)*blocksize;
        ssd = zeros(2*searchrange+1);
        ssd(:,:) = Inf;
        for k = % To DO 2.1.2
            for l= % To DO 2.1.2
                if (m+k)>0 && (n+l)>0 && (m+blocksize+k)<=size(g,1) && (n+blocksize+l)<=size(g,2)
                    ssd(k+searchrange+1,l+searchrange+1) = % To DO 2.1.3         
                end
            end
        end
        
        % Determine the motion vector for each block at the indicated position
        % To Do 2.1.4
    end
end

%% Show the first frame of the sequence and overlay it with a plot of the resulting motion vectors.
% To Do 2.1.5

