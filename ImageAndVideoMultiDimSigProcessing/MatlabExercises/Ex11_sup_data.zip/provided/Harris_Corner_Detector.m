clear all
close all

%% Load image
img = checkerboard(16);
img = (img > 0.5);
img = im2double(img);

%% Initalize parameters
w = fspecial('gaussian',[3 3],2);
k = 0.01;
height = size(img,1);
width = size(img,2);

%% Compute local derivatives of image
for x = 2:size(img,1)
    s_x(x,:) = % To DO 2.1.1
end
for y = 2:size(img,2)
    s_y(:,y) = % To DO 2.1.1
end

%% Compute products of local derivatives at every pixel
s_xx = % To DO 2.1.2
s_xy = % To DO 2.1.2
s_yy = % To DO 2.1.2

%% Compute sums of weighted products of derivatives at each pixel

s_xx = filter2(% To DO 2.1.3);
s_xy = filter2(% To DO 2.1.3);
s_yy = filter2(% To DO 2.1.3);

%% Define at each pixel (x,y) Harris structure matrix M
for i = 1:height
    for j = 1:width
        M = [% To DO 2.1.4];
            
        % Compute cornerness c[x,y] at each pixel (x,y)
        c(i,j) = % To DO 2.1.5
    end
end

%% Apply nonmax suppression

% Define threshold
c_max = max(max(c));
threshold = c_max * 0.1;
% Apply thresholding
cornerCandidates = % To DO 2.1.6 a
% nonmax suppression
result = zeros(size(c));
% check 3x3 neighbourhood
for i = 2:height-1
    for j = 2:width-1
        if cornerCandidates(i,j) == 1
            if % To DO 2.1.6 b
                result(i,j) = 1;
            end
        end
    end
end

%% Return the x and y coordinates of the detected corners
% To DO 2.1.7

%% Show the image and plot the detected corners
% To DO 2.1.8
