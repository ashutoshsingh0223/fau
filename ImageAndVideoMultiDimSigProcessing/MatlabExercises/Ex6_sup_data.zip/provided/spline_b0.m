function y = spline_b0(x)

y = (((-0.5 < x) & (x <=  0.5)) .* 1);

