"""PyTorch MNIST Example."""


from __future__ import print_function
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
from torch.optim.lr_scheduler import StepLR


class Net(nn.Module):
    """A neural network implementation."""
    def __init__(self):
        super(Net, self).__init__()
        # TODO: Define the member variables for your layers.
        # Use the appropriate layers from torch.nn
        self.conv1 = None

    def forward(self, x):
        # Implement one forward pass of your neural network.
        return torch.zeros((x.size(0), 4))


def train(model, device, train_loader, optimizer, epoch, args):
    """Train the model for one epoch."""
    # This indicates to the model that it is used for training.
    # Will, e.g., change how dropout layers operate.
    model.train()

    # Inner training loop: Iterate over batches
    for batch_idx, (data, target) in enumerate(train_loader):
        # Move data and target to the correct device (cpu/gpu).
        data, target = data.to(device), target.to(device)

        # TODO: implement one step of the optimization:
        # * Calculate predictions
        # * Calculate the loss
        # * Backpropagate the loss to find the gradients
        # * Take one gradient step with your optimizer
        

        # Assign your loss value here for easy printing
        loss_for_printing = 0
        if batch_idx % args["log_interval"] == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch, batch_idx * len(data), len(train_loader.dataset),
                100. * batch_idx / len(train_loader), loss_for_printing))
            if args["dry_run"]:
                break


def test(model, device, test_loader):
    """Test the model on the specified test set, and print test loss and accuracy."""
    # Similar to .train() above, this will tell the model it is used for inference.
    model.eval()

    # Accumulator for the loss over the test dataset
    test_loss = 0
    # Accumulator for the number of correctly classified items
    correct = 0
    
    # This block will not compute any gradients
    with torch.no_grad():
        # Similar to the inner training loop, only over the test_loader
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            
            # TODO: Implement the same loss calculations as in training
            # No optimizer step here.

            # TODO: Calculate the predictions of your model over the batch

            # TODO: Calculate how many predictions were correct, and add them here
            correct += 0

    test_loss /= len(test_loader.dataset)

    print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
        test_loss, correct, len(test_loader.dataset),
        100. * correct / len(test_loader.dataset)))


def get_mnist_loaders(batch_size):
    """Creates train- and test-DataLoaders for MNIST with the specified batch size."""
    train_kwargs = {'batch_size': batch_size}
    test_kwargs = {'batch_size': batch_size}

    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))
    ])
    dataset1 = datasets.MNIST('data', train=True, download=True,
                       transform=transform)
    dataset2 = datasets.MNIST('data', train=False, download=True,
                       transform=transform)
    train_loader = torch.utils.data.DataLoader(dataset1,**train_kwargs)
    test_loader = torch.utils.data.DataLoader(dataset2, **test_kwargs)

    return train_loader, test_loader

def main():

    # Seed your model for reproducibility
    torch.manual_seed(4711)

    # If possible, use CUDA (i.e., your GPU) for computations.
    use_cuda = torch.cuda.is_available()
    device = torch.device("cuda" if use_cuda else "cpu")

    # Training Parameters
    learning_rate = 1.0
    batch_size = 64
    epochs = 14
    training_args = dict(
        log_interval=10,
        dry_run=False
    )
    
    # Retrieve DataLoaders for the train- and test-dataset.
    train_loader, test_loader = get_mnist_loaders(batch_size)

    # Create your network, and move it to the specified device
    model = Net().to(device)

    # TODO: Create your optimizer here
    optimizer = None

    # The outer training loop (over epochs)
    for epoch in range(1, epochs + 1):
        train(model, device, train_loader, optimizer, epoch, training_args)
        test(model, device, test_loader)

    # Save the trained model.
    torch.save(model.state_dict(), "mnist_cnn.pt")


if __name__ == '__main__':
    main()