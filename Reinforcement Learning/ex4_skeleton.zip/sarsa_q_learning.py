import numpy as np
import random
from helper import action_value_plot, test_agent

from gym_gridworld import GridWorldEnv

class SARSAQBaseAgent:
    def __init__(self, env, discount_factor, learning_rate, epsilon):
        self.g = discount_factor
        self.lr = learning_rate
        self.eps = epsilon
        self.env = env

        # TODO: define a Q-function member variable self.Q
        # Remark: Use this kind of Q-value member variable for visualization tools to work, i.e. of shape [grid_height, grid_width, num_actions]
        # Q[y, x, z] is value of action z for grid position y, x
        self.Q = np.zeros([4, 4, 4], dtype=np.float32)

    def action(self, s, epsilon=0.0):
        # TODO: implement epsilon-greedy action selection
        return 0

class SARSAAgent(SARSAQBaseAgent):
    def __init__(self, env, discount_factor, learning_rate, epsilon):
        super(SARSAAgent, self).__init__(env, discount_factor, learning_rate, epsilon)

    def learn(self, n_timesteps=50000):
        # TODO: implement training loop
        pass

    def update_Q(self, s, a, r, s_, a_):
        # TODO: implement Q-value update rule
        pass


class QLearningAgent(SARSAQBaseAgent):
    def __init__(self, env, discount_factor, learning_rate, epsilon):
        super(QLearningAgent, self).__init__(env, discount_factor, learning_rate, epsilon)

    def learn(self, n_timesteps=50000):
        # TODO: implement training loop
        pass

    def update_Q(self, s, a, r, s_):
        # TODO: implement Q-value update rule
        pass


if __name__ == "__main__":
    # Create environment
    env = GridWorldEnv()

    discount_factor = 0.9
    learning_rate = 0.1
    epsilon = 0.4
    n_timesteps = 100000

    # Train SARSA agent
    sarsa_agent = SARSAAgent(env, discount_factor, learning_rate, epsilon)
    sarsa_agent.learn(n_timesteps=n_timesteps)
    action_value_plot(sarsa_agent)
    # Uncomment to do a test run
    #print("Testing SARSA agent...")
    #test_agent(sarsa_agent, env, epsilon)

    # Train Q-Learning agent
    qlearning_agent = QLearningAgent(env, discount_factor, learning_rate, epsilon)
    qlearning_agent.learn(n_timesteps=n_timesteps)
    action_value_plot(qlearning_agent)
    # Uncomment to do a test run
    #print("Testing Q-Learning agent...")
    #test_agent(qlearning_agent, env, 0.0)
