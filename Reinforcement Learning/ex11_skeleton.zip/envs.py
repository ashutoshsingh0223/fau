import numpy as np
from typing import Optional
from gym.envs.classic_control.mountain_car import MountainCarEnv


class MultiArmedBandit:
    def __init__(self, reward_probability_list):
        """ Create a new bandit environment.

        It is possible to pass the parameter of the simulation.
        @param: reward_probability_list: each value correspond to
            probability [0, 1] of obtaining a positive reward of +1.
            For each value in the list an arm is defined.
            e.g. [0.3, 0.5, 0.2, 0.8] defines 4 arms, the last one
            having higher probability (0.8) of returning a reward.
        """
        self.reward_probability_list = np.array(reward_probability_list)

    def step(self, action):
        """Pull the arm indicated in the 'action' parameter.

        @param: action an integer representing the arm to pull.
        @return: reward it returns the reward obtained pulling that arm
        """
        if action > len(self.reward_probability_list):
            raise Exception("Invalid action!")
        p = self.reward_probability_list[action]
        q = 1.0 - p
        return None, np.random.choice(2, p=[q, p]), False, {}

    def reset(self):
        return None

    @property
    def state_dim(self):
        return None

    @property
    def action_dim(self):
        return self.reward_probability_list.shape[0]

    @property
    def utility(self):
        return self.reward_probability_list


class MountainCarDiscretizedEnv(MountainCarEnv):
    metadata = {
        "render_modes": ["human", "rgb_array", "single_rgb_array"],
        "render_fps": 10000,
    }

    # Taken from OpenAI Gym implementation
    # See: https://github.com/openai/gym/blob/master/gym/envs/classic_control/mountain_car.py
    def __init__(self, goal_velocity=0, num_bins_per_dim=[18, 14]):
        super().__init__(goal_velocity=goal_velocity)
        # Looking at the original constructor, you have the following attributes at your disposal
        # self.min_position = -1.2
        # self.max_position = 0.6
        # self.max_speed = 0.07  # min_speed is defined as - self.max_speed

        self._position_bins = np.linspace(self.min_position, self.max_position, num=num_bins_per_dim[0]-1, endpoint=False)
        self._speed_bins = np.linspace(-self.max_speed, self.max_speed, num=num_bins_per_dim[1]-1, endpoint=False)
        self._num_bins_per_dim = num_bins_per_dim
        self._time_step = 0

        self.screen_width = 600
        self.screen_height = 400
        self.screen = None
        self.clock = None
        self.isopen = True

    def step(self, action):
        obs, reward, done, info = super().step(action)
        self._time_step += 1
        if self._time_step == 200:
            # We have to add this because wo don't use the gym timeout wrapper
            done = True

        return self._discretize_obs(obs), reward, done, info

    def reset(
            self,
            *,
            seed: Optional[int] = None,
            return_info: bool = False,
            options: Optional[dict] = None,
    ):
        obs = super().reset()
        self._time_step = 0
        return self._discretize_obs(obs)

    def _discretize_obs(self, obs):
        obs[0] = np.digitize(obs[0], self._position_bins)
        obs[1] = np.digitize(obs[1], self._speed_bins)
        obs = obs.astype(np.int8)
        return obs

    @property
    def state_dim(self):
        return np.array(self._num_bins_per_dim)

    @property
    def action_dim(self):
        return np.array([3])

    def render(self, mode="human"):
        return self._render(mode)

    def _render(self, mode="human"):
        # This is the original render function, just without slowing rendering down to 30 FPS
        assert mode in self.metadata["render_modes"]
        try:
            import pygame
            import math
            from pygame import gfxdraw
        except ImportError:
            raise Exception(
                "pygame is not installed, run `pip install gym[classic_control]`"
            )

        if self.screen is None:
            pygame.init()
            if mode == "human":
                pygame.display.init()
                self.screen = pygame.display.set_mode(
                    (self.screen_width, self.screen_height)
                )
            else:  # mode in {"rgb_array", "single_rgb_array"}
                self.screen = pygame.Surface((self.screen_width, self.screen_height))
        if self.clock is None:
            self.clock = pygame.time.Clock()

        world_width = self.max_position - self.min_position
        scale = self.screen_width / world_width
        carwidth = 40
        carheight = 20

        self.surf = pygame.Surface((self.screen_width, self.screen_height))
        self.surf.fill((255, 255, 255))

        pos = self.state[0]

        xs = np.linspace(self.min_position, self.max_position, 100)
        ys = self._height(xs)
        xys = list(zip((xs - self.min_position) * scale, ys * scale))

        pygame.draw.aalines(self.surf, points=xys, closed=False, color=(0, 0, 0))

        clearance = 10

        l, r, t, b = -carwidth / 2, carwidth / 2, carheight, 0
        coords = []
        for c in [(l, b), (l, t), (r, t), (r, b)]:
            c = pygame.math.Vector2(c).rotate_rad(math.cos(3 * pos))
            coords.append(
                (
                    c[0] + (pos - self.min_position) * scale,
                    c[1] + clearance + self._height(pos) * scale,
                )
            )

        gfxdraw.aapolygon(self.surf, coords, (0, 0, 0))
        gfxdraw.filled_polygon(self.surf, coords, (0, 0, 0))

        for c in [(carwidth / 4, 0), (-carwidth / 4, 0)]:
            c = pygame.math.Vector2(c).rotate_rad(math.cos(3 * pos))
            wheel = (
                int(c[0] + (pos - self.min_position) * scale),
                int(c[1] + clearance + self._height(pos) * scale),
            )

            gfxdraw.aacircle(
                self.surf, wheel[0], wheel[1], int(carheight / 2.5), (128, 128, 128)
            )
            gfxdraw.filled_circle(
                self.surf, wheel[0], wheel[1], int(carheight / 2.5), (128, 128, 128)
            )

        flagx = int((self.goal_position - self.min_position) * scale)
        flagy1 = int(self._height(self.goal_position) * scale)
        flagy2 = flagy1 + 50
        gfxdraw.vline(self.surf, flagx, flagy1, flagy2, (0, 0, 0))

        gfxdraw.aapolygon(
            self.surf,
            [(flagx, flagy2), (flagx, flagy2 - 10), (flagx + 25, flagy2 - 5)],
            (204, 204, 0),
        )
        gfxdraw.filled_polygon(
            self.surf,
            [(flagx, flagy2), (flagx, flagy2 - 10), (flagx + 25, flagy2 - 5)],
            (204, 204, 0),
        )

        self.surf = pygame.transform.flip(self.surf, False, True)
        self.screen.blit(self.surf, (0, 0))
        if mode == "human":
            pygame.event.pump()
            self.clock.tick(self.metadata["render_fps"])
            pygame.display.flip()

        elif mode in {"rgb_array", "single_rgb_array"}:
            return np.transpose(
                np.array(pygame.surfarray.pixels3d(self.screen)), axes=(1, 0, 2)
            )
