t=1
while [ $t -lt 20 ]
do
   export OMP_NUM_THREADS=$t
   echo "threads=" $OMP_NUM_THREADS
   ./hist_omp
   t=`expr $t + 1`
   echo $'---------------------------------------------\n'
done
