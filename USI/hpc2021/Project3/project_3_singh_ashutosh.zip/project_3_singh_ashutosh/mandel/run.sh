t=5
while [ $t -lt 25 ]
do
   echo "t=" $t
   export OMP_NUM_THREADS=$t
   echo "threads=" $OMP_NUM_THREADS
   ./mandel_omp
   t=`expr $t + 1`
   echo $'---------------------------------------------\n'
done
