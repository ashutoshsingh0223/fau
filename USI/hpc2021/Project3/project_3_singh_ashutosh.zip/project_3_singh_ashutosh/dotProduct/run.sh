#export OMP_NUM_THREADS=t

t=1
while [ $t -lt 25 ]
do
   export OMP_NUM_THREADS=$t
   echo "threads=" $OMP_NUM_THREADS
   for N in 100000 1000000 10000000 100000000 1000000000
   do
      ./dotProduct $N
      echo $'\n'
   done
   t=`expr $t + 1` 
   echo $'---------------------------------------------\n'
done
