/* 
    Please include compiler name below (you may also include any other modules you would like to be loaded)

COMPILER= gnu

    Please include All compiler flags and libraries as you want them run. You can simply copy this over from the Makefile's first few lines
 
CC = cc
OPT = -O3
CFLAGS = -Wall -std=gnu99 $(OPT)
MKLROOT = /opt/intel/composer_xe_2013.1.117/mkl
LDLIBS = -lrt -Wl,--start-group $(MKLROOT)/lib/intel64/libmkl_intel_lp64.a $(MKLROOT)/lib/intel64/libmkl_sequential.a $(MKLROOT)/lib/intel64/libmkl_core.a -Wl,--end-group -lpthread -lm

*/
#include <math.h>
#include <stdio.h>
const char* dgemm_desc = "Naive, three-loop dgemm.";

/* This routine performs a dgemm operation
 *  C := C + A * B
 * where A, B, and C are lda-by-lda matrices stored in column-major format.
 * On exit, A and B maintain their input values. */   

/*int highestPowerof2(int n)
{
    int res = 0;
    for (int i=n; i>=1; i--)
    {
        // If i is a power of 2
        if ((i & (i-1)) == 0)
        {
            res = i;
            break;
        }
    }
    return res;
}

void main(){
   int s = 0;
   int x[] = {10, 18, 16, 31, 32};
   for (int i=0; i<=4; i++){
   s = highestPowerof2(x[i]);
   printf("out: %d", s);
   }
}
*/

#define min(a,b) (((a)<(b))?(a):(b))



// timing_s_36 - s=36 and if s > n --> s = n only considering l1 cache

void square_dgemm (int n, double* A, double* B, double* C)
{
  int s = 36;

  if (s < n){
  }
  else{
     //s = n;
  }

  for (int i_b = 0; i_b < n; i_b += s)
  {

    for (int j_b = 0; j_b < n; j_b += s)
    {
      for (int k_b = 0; k_b < n; k_b += s)
      {
        int M = min (s, n - i_b);
	int N = min (s, n - j_b);
	int K = min (s, n - k_b);
        //For each row i of A_
        for (int i = i_b; i < i_b + M; i++)
        {
          // For each column j of B_
          for (int j = j_b; j < j_b + N; j++)
          {
            // Compute C_(i,j) 
            double cij = C[i + j*n];
            for( int k = k_b; k < k_b + K; k++)
	      
              {cij += A[i + k * n] * B[k + j * n];}

            C[i + j*n] = cij;

          }
        }
      }

    }
  }
}
